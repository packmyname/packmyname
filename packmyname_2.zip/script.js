function startTimer() {
    let time = 24 * 60 * 60;
    const timerElement = document.getElementById('timer');
    setInterval(() => {
        const hours = Math.floor(time / 3600);
        const minutes = Math.floor((time % 3600) / 60);
        const seconds = time % 60;
        timerElement.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        time--;
        if (time < 0) time = 24 * 60 * 60;
    }, 1000);
}
document.addEventListener('DOMContentLoaded', startTimer);